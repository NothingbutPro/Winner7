package android.ics.com.winner7;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LatestWinnerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_latest_winner);
    }
}

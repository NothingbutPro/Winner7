package android.ics.com.winner7;

import android.app.ProgressDialog;
import android.ics.com.winner7.Adapter.TestAdapter;
import android.ics.com.winner7.Model.TestModel;
import android.ics.com.winner7.Utils.Connectivity;
import android.ics.com.winner7.Utils.HttpHandler;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class QuizActivity extends AppCompatActivity {
    String server_url;
    TextView tv_quiz_subject, tv_quiz_ans1, tv_quiz_ans2, tv_quiz_ans3, tv_quiz_ans4, tv_quiz_ans5, tv_quiz_ans6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        tv_quiz_subject = (TextView) findViewById(R.id.tv_quiz_subject);
        tv_quiz_ans1 = (TextView) findViewById(R.id.tv_quiz_ans1);
        tv_quiz_ans2 = (TextView) findViewById(R.id.tv_quiz_ans2);
        tv_quiz_ans3 = (TextView) findViewById(R.id.tv_quiz_ans3);
        tv_quiz_ans4 = (TextView) findViewById(R.id.tv_quiz_ans4);
        tv_quiz_ans5 = (TextView) findViewById(R.id.tv_quiz_ans5);
        tv_quiz_ans6 = (TextView) findViewById(R.id.tv_quiz_ans6);

        if (Connectivity.isNetworkAvailable(QuizActivity.this)) {
            new GetQuizQuestions().execute();
        } else {
            Toast.makeText(this, "No Internet", Toast.LENGTH_SHORT).show();
        }
    }

    //------------------------------------------

    class GetQuizQuestions extends AsyncTask<String, String, String> {
        String output = "";
        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            dialog = new ProgressDialog(QuizActivity.this);
            dialog.setMessage("Processing");
            dialog.setCancelable(true);
            dialog.show();
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... params) {

            try {
                server_url = "http://ihisaab.in/winnerseven/api/getquiz";
            } catch (Exception e) {
                e.printStackTrace();
            }
            Log.e("sever_url>>>>>>>>>", server_url);
            output = HttpHandler.makeServiceCall(server_url);
            System.out.println("getcomment_url" + output);
            return output;
        }

        @Override
        protected void onPostExecute(String output) {
            if (output == null) {
                dialog.dismiss();
            } else {
                try {
                    dialog.dismiss();
                    JSONObject obj = new JSONObject(output);
                    String responce = obj.getString("responce");
                    if (responce.equals("true")) {
                        JSONArray data_array = obj.getJSONArray("data");
                        for (int i = 0; i < data_array.length(); i++) {
                            JSONObject c = data_array.getJSONObject(i);
                            String id = c.getString("id");
                            String Que = c.getString("Que");
                            String Ans_1 = c.getString("Ans_1");
                            String Ans_2 = c.getString("Ans_2");
                            String Ans_3 = c.getString("Ans_3");
                            String Ans_4 = c.getString("Ans_4");
                            String Ans = c.getString("Ans");
                            String marks = c.getString("marks");
                            String Createdate = c.getString("Createdate");
                            String status = c.getString("status");

                            tv_quiz_subject.setText(Que);
                            tv_quiz_ans1.setText(Ans_1);
                            tv_quiz_ans2.setText(Ans_2);
                            tv_quiz_ans3.setText(Ans_3);
                            tv_quiz_ans4.setText(Ans_4);
                               /*     tv_quiz_ans5.setText();
                            tv_quiz_ans6.setText();*/
                        }
                    } else {
                        Toast.makeText(QuizActivity.this, "Some Problem!", Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    //  dialog.dismiss();
                }
                super.onPostExecute(output);
            }
        }
    }
}
